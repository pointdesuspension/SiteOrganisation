# site ...

site du serveur discord **...**

c'est un serveur discord communautaire parlant de code et graphisme principalement, mais surtout de tout et de rien 


